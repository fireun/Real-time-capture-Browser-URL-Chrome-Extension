from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/GetURL', methods=['POST'])
def handle_data():
    data = request.get_json()

    # Access the URLs
    urls = data.get('urls', [])

    # Process each URL individually (e.g., store them in a database)
    for url in urls:
        
        # Skip chrome://new-tab-page/ OR about:blank OR https://www.google.com/search?q=
        #if url.startswith('chrome://new-tab-page/'):
        if url.startswith('chrome://new-tab-page/') or url.startswith('about:blank') or 'https://www.google.com/search?q=' in url:
            #print(f"Skipping new tab page URL: {url}")
            continue

        else:
            print(f"Processing URL: {url}")
        # Your processing logic here...

    # Send a response (optional)
    return jsonify({'status': 'success'})

if __name__ == '__main__':
    app.run(port=8000)
